<script setup>

import {InboxOutlined} from '@ant-design/icons-vue';

</script>

<template>
  <div class="Container">

    
  </div>

</template>


<style scoped>


</style>