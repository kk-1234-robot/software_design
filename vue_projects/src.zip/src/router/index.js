// // src/router/index.js
// import { createRouter, createWebHistory } from 'vue-router'
// import Login from '../components/Login.vue' // 确保路径正确
// import Welcome from '../components/TheWelcome.vue' // 确保路径正确
//
// // 定义路由数组
// const routes = [
//     {
//         path: '/',
//         name: 'Login',
//         component: Login
//     },
//     {
//         path: '/welcome',
//         name: 'Welcome',
//         component: Welcome
//     }
// ]
//
// // 创建路由器实例
// let process;
// const router = createRouter({
//     history: createWebHistory(process.env.BASE_URL),
//     routes
// })
//
// // 导出路由器实例
// export default router